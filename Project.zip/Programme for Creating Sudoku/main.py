# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import random
import numpy as np
from pymzn import dzn


class Sudoku:
    def __init__(self):
        # initialize the grid
        self.board = np.zeros((9, 9), dtype=int, order='C')

    def available_num(self, row, col):
        possible_nums = {1, 2, 3, 4, 5, 6, 7, 8, 9}
        temp_row, temp_col = row // 3, col // 3
        #  extract the rows labeled by row
        row_set = set(self.board[row])
        #  extract the cols labeled by col
        col_set = set(self.board[:, col])
        #  according to the row label, take out the 3x3 grid
        subgrid_set = set(self.board[temp_row * 3: temp_row * 3 + 3,
                          temp_col * 3: temp_col * 3 + 3].reshape(9))
        #  remove the same number in the row, column, and 3x3 grid from possible
        return possible_nums - row_set - col_set - subgrid_set

    def initialize(self, init_given_count):
        # initGivenCount is the number of blocks with initial value.
        while init_given_count:
            # use random function the locate a block randomly.
            row = random.randint(0, 8)
            col = random.randint(0, 8)
            # only choose blank blocks( tagged by 0 value), and avoid choosing those blocks which have already chosen.
            if self.board[row, col] == 0:
                # choose a random number in the possible values to avoid only use 1,2,3 to fill those initial block.
                tp = np.random.choice(list(self.available_num(row, col)), 1)
                value = tp[0]
                self.board[row, col] = value
                init_given_count -= 1
        # output the Sudoku.
        self.output_Sudoku()
        #  use DFS function to solve this Sudoku.
        if self.dfs():
            return True
        else:
            return False

    def dfs(self):
        for row in range(9):
            for col in range(9):
                # Look for blank blocks starting from row 0 and column 0
                if self.board[row, col] == 0:
                    #  use get_possible function to obtain the possible value of the current blank block
                    poss4current = self.available_num(row, col)
                    # Deep-first, fill in the first value, and recursively fill in the value of remaining blank blocks
                    # if cannot get the correct answer, go back to the previous block and fill it with the next value in set Possible
                    # loop until all the blanks are filled in correctly
                    for value in poss4current:
                        self.board[row, col] = value
                        if self.dfs():
                            return True
                        self.board[row, col] = 0
                    return False
        return True

    def only1answer(self, row, col, origin_board):
        rest_choice = set(range(1, 10))
        rest_choice.remove(self.board[row, col])
        for value in rest_choice:
            if value in self.available_num(row, col):
                # first check if this number in the get_possible set.
                # try this possible numbers  and check whether we can get a answer.
                self.board[row, col] = value
                if self.dfs():
                    return False
            # cause we changed the value of self.board, here we need to restore the status before the change of number, and continue with other numbers.
            self.board = origin_board.copy()
        # tried all other numbers and find no solution, which means after digging this block, the generated Sudoku has and only has one solution.
        return True

    def dig(self, dignum):
        # dignum represents the number of blocks we are going to dig.
        temp_board = self.board.copy()
        dug = 0
        while dug < dignum:
            row = random.randint(0, 8)
            col = random.randint(0, 8)
            # jump those blocks which is dug before.
            if temp_board[row, col] == 0:
                continue
            # check whether the grid which has been dug the current block has only solution. If so, then dig this block. If no, jump this block.
            if self.only1answer(row, col, temp_board):
                # save the status after dredging.
                temp_board[row, col] = 0
                # keep dredging, until the specific number of blocks have been removed.
                self.board = temp_board.copy()
                dug += 1

    def output_Sudoku(self):

        for i in range(9):
            if i % 3 == 0:
                print('  |*******|*******|*******|')
            print('  ', end='')
            for j in range(9):
                if j in [0, 3, 6]:
                    print("| ", end="")
                if self.board[i, j] != 0:
                    print(self.board[i, j], end=' ')
                else:
                    print(" ", end=" ")
                if j == 8:
                    print("|", end="")
            print("")
        print('  |*******|*******|*******|')


NUM = eval(
    input('\nimput a number, and programme will generate a corresponding basic Sudoku according to this number：'))

mySudoku = Sudoku()
print('\nthe generated basic Sudoku is as following:')
mySudoku.initialize(NUM)

print('\nThe answer of this Sudoku is as following:')
mySudoku.output_Sudoku()

# output the Sudoku after digging
digCount = eval(input('\ninput the number of blocks for digging:'))
mySudoku.dig(digCount)
temp = mySudoku.board
print('\nthe Sudoku after digging given number of block:')
mySudoku.output_Sudoku()
print('\nturn the Sudoku puzzle into MiniZinc data file')
data = {
    "nrow": 9,
    "grid": temp,
    "ncol": 9,
}

with open("C:/Users/41640/Desktop/MINIZINC/data4sdk.dzn", "w") as f:
    f.write("\n".join(dzn.dict2dzn(data)))

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
